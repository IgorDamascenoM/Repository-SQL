select SalesOrderID,  OrderDate, TotalDue
from [Sales.SalesOrderHeader]
 
where 
	Status = 1
and OrderDate between '01/09/2011' and '30/09/2011'
and TotalDue > 1000
order by TotalDue desc, data

