/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [SalesOrderID]
      ,[SalesOrderDetailID]
      ,[CarrierTrackingNumber]
      ,[OrderQty]
      ,[ProductID]
      ,[SpecialOfferID]
      ,[UnitPrice]
      ,[UnitPriceDiscount]
      ,[LineTotal]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [2RPNET].[dbo].[Sales.SalesOrderDetail]

    update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set SalesOrderID = null
  where SalesOrderID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set SalesOrderDetailID = null
  where SalesOrderDetailID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set CarrierTrackingNumber = null
  where CarrierTrackingNumber = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set OrderQty = null
  where OrderQty = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set ProductID = null
  where ProductID ='NULL'  
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set SpecialOfferID = null
  where SpecialOfferID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set UnitPrice = null
  where UnitPrice = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set UnitPriceDiscount = null
  where UnitPriceDiscount = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set LineTotal = null
  where LineTotal = 'NULL'
  
  update [2RPNET].[dbo].[Sales.SalesOrderDetail]
  
  set rowguid = null
  where rowguid = 'NULL'