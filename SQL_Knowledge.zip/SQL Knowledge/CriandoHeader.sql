USE [2RPNET]
GO

/****** Object:  Table [dbo].[Sales.SalesOrderHeader]    Script Date: 22/12/2021 18:24:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sales.SalesOrderHeader](
	[SalesOrderID] [int] NOT NULL,
	[RevisionNumber] [int] NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL,
	[Status] [int] NULL,
	[OnlineOrderFlag] [bit] NULL,
	[SalesOrderNumber] [varchar](50) NULL,
	[PurchaseOrderNumber] [varchar](50) NULL,
	[AccountNumber] [varchar](50) NULL,
	[CustomerID] [int] NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NULL,
	[ShipToAddressID] [int] NULL,
	[ShipMethodID] [int] NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](50) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [float] NULL,
	[TaxAmt] [float] NULL,
	[Freight] [float] NULL,
	[TotalDue] [float] NULL,
	[Comment] [varchar](50) NULL,
	[rowguid] [varchar](50) NULL,
	[ModifiedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Sales.SalesOrderHeader] PRIMARY KEY CLUSTERED 
(
	[SalesOrderID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Custo__03F0984C] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Sales.Customer] ([CustomerID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader] CHECK CONSTRAINT [FK__Sales.Sal__Custo__03F0984C]
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Custo__17036CC0] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Sales.Customer] ([CustomerID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader] CHECK CONSTRAINT [FK__Sales.Sal__Custo__17036CC0]
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Custo__1CBC4616] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Sales.Customer] ([CustomerID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderHeader] CHECK CONSTRAINT [FK__Sales.Sal__Custo__1CBC4616]
GO


