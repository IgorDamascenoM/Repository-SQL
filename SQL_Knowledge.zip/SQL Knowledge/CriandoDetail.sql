USE [2RPNET]
GO

/****** Object:  Table [dbo].[Sales.SalesOrderDetail]    Script Date: 22/12/2021 18:24:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sales.SalesOrderDetail](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[CarrierTrackingNumber] [varchar](50) NULL,
	[OrderQty] [int] NULL,
	[ProductID] [int] NULL,
	[SpecialOfferID] [int] NULL,
	[UnitPrice] [float] NULL,
	[UnitPriceDiscount] [float] NULL,
	[LineTotal] [float] NULL,
	[rowguid] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [pk_orderdetail] PRIMARY KEY CLUSTERED 
(
	[SalesOrderID] ASC,
	[SalesOrderDetailID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Produ__08B54D69] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Produ__08B54D69]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Sales__07C12930] FOREIGN KEY([SalesOrderID])
REFERENCES [dbo].[Sales.SalesOrderHeader] ([SalesOrderID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Sales__07C12930]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Sales__0E6E26BF] FOREIGN KEY([SalesOrderID])
REFERENCES [dbo].[Sales.SalesOrderHeader] ([SalesOrderID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Sales__0E6E26BF]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Sales__123EB7A3] FOREIGN KEY([SalesOrderID])
REFERENCES [dbo].[Sales.SalesOrderHeader] ([SalesOrderID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Sales__123EB7A3]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Sales__18EBB532] FOREIGN KEY([SalesOrderID])
REFERENCES [dbo].[Sales.SalesOrderHeader] ([SalesOrderID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Sales__18EBB532]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK__Sales.Sal__Sales__1EA48E88] FOREIGN KEY([SalesOrderID])
REFERENCES [dbo].[Sales.SalesOrderHeader] ([SalesOrderID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail] CHECK CONSTRAINT [FK__Sales.Sal__Sales__1EA48E88]
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([SpecialOfferID], [ProductID])
REFERENCES [dbo].[Sales.SpecialOfferProduct] ([SpecialOfferID], [ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([SpecialOfferID], [ProductID])
REFERENCES [dbo].[Sales.SpecialOfferProduct] ([SpecialOfferID], [ProductID])
GO

ALTER TABLE [dbo].[Sales.SalesOrderDetail]  WITH CHECK ADD FOREIGN KEY([SpecialOfferID], [ProductID])
REFERENCES [dbo].[Sales.SpecialOfferProduct] ([SpecialOfferID], [ProductID])
GO

