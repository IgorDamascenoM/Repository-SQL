-- Chave estrangeira PersonID na tabela Sales.Costumer

alter table [Sales.Customer]
add foreign key (PersonID)
references [Person.person] (BusinessEntityID)

-- Chave estrangeira CustomerID na tabela Sales.SalesOrderHeader

alter table [Sales.SalesOrderHeader]
add foreign key (CustomerID)
references [Sales.Customer] (CustomerID)

-- Chave estrangeira ProductID na tabela SpecialOfferProduct

alter table [Sales.SpecialOfferProduct]
add foreign key (ProductID)
references [Production.Product] (ProductID)

-- Chaves estrangeiras ProductID, SpecialOfferID e SalesOrderID na tabela SaleOrderDetail

alter table [Sales.SalesOrderDetail]
add foreign key (SalesOrderID)
references [Sales.SalesOrderHeader] (SalesOrderID)

alter table [Sales.SalesOrderDetail]
add foreign key (ProductID)
references [Production.Product] (ProductID)

alter table [Sales.SalesOrderDetail]
add foreign key (SpecialOfferID,ProductID)
references [Sales.SpecialOfferProduct] (SpecialOfferID,ProductID)

-- criando chave primaria para a tabela SpecialOfferProduct

alter table [Sales.SpecialOfferProduct]
add CONSTRAINT pk_specialoffer primary key(SpecialOfferID,ProductID)

-- criando chave primaria para a tabela SalesOrderDetail

alter table [Sales.SalesOrderDetail]
add CONSTRAINT pk_orderdetail primary key(SalesOrderID,SalesOrderDetailID)