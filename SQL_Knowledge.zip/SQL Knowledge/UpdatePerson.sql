
SELECT TOP (1000) [BusinessEntityID]
      ,[PersonType]
      ,[NameStyle]
      ,[Title]
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Suffix]
      ,[EmailPromotion]
      ,[AdditionalContactInfo]
      ,[Demographics]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [2RPNET].[dbo].[Person.Person]

update [2RPNET].[dbo].[Person.Person]

set NameStyle = null
where  NameStyle = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set Title = null
where  Title = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set FirstName = null
where FirstName = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set MiddleName = null
where MiddleName ='NULL'

update [2RPNET].[dbo].[Person.Person]

set LastName = null
where LastName ='NULL'

update [2RPNET].[dbo].[Person.Person]

set Suffix = null
where Suffix = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set EmailPromotion = null
where EmailPromotion = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set AdditionalContactInfo = null
where AdditionalContactInfo = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set Demographics = null
where Demographics = 'NULL'

update [2RPNET].[dbo].[Person.Person]

set rowguid = null
where rowguid = 'NULL'