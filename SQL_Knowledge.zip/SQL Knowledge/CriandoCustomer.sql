USE [2RPNET]
GO

/****** Object:  Table [dbo].[Sales.Customer]    Script Date: 22/12/2021 18:23:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sales.Customer](
	[CustomerID] [int] NOT NULL,
	[PersonID] [int] NULL,
	[StoreID] [int] NULL,
	[TerritoryID] [int] NULL,
	[AccountNumber] [varchar](50) NULL,
	[rowguid] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Sales.Customer] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Sales.Customer]  WITH CHECK ADD FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person.Person] ([BusinessEntityID])
GO

ALTER TABLE [dbo].[Sales.Customer]  WITH CHECK ADD FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person.Person] ([BusinessEntityID])
GO

ALTER TABLE [dbo].[Sales.Customer]  WITH CHECK ADD FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person.Person] ([BusinessEntityID])
GO

ALTER TABLE [dbo].[Sales.Customer]  WITH CHECK ADD FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person.Person] ([BusinessEntityID])
GO

ALTER TABLE [dbo].[Sales.Customer]  WITH CHECK ADD FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person.Person] ([BusinessEntityID])
GO


