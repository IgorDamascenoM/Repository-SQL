/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [CustomerID]
      ,[PersonID]
      ,[StoreID]
      ,[TerritoryID]
      ,[AccountNumber]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [2RPNET].[dbo].[Sales.Customer]

  update [2RPNET].[dbo].[Sales.Customer]

  set CustomerID = null
  where CustomerID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set PersonID = null
  where PersonID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set StoreID = null
  where StoreID ='NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set TerritoryID = null
  where TerritoryID = 'NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set AccountNumber = null
  where AccountNumber = 'NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set rowguid = null
  where rowguid = 'NULL'
  
  update [2RPNET].[dbo].[Sales.Customer]

  set ModifiedDate = null
  where ModifiedDate = 'NULL'