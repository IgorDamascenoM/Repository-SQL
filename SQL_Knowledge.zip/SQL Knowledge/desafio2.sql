--Escreva uma query que ligue as tabelas Sales.SalesOrderDetail, Sales.SpecialOfferProduct e Production.Product e retorne os 3 produtos (Name) mais vendidos (pela soma de OrderQty), 
--agrupados pelo n�mero de dias para manufatura (DaysToManufacture).


select * from 
	(
	select c.DaysToManufacture, c.Name, SUM (a.OrderQty) as TotalVendas,
	
	ROW_NUMBER() over(partition by c.DaysToManufacture order by SUM (a.OrderQty)desc) as posicao
	from [Sales.SalesOrderDetail] as a
	inner join [Sales.SpecialOfferProduct] as b
	on a.ProductID = b.ProductID
	and a.SpecialOfferID = b.SpecialOfferID
	inner join [Production.Product] as c
	on b.ProductID = c.ProductID
	Group by c.Name, c.DaysToManufacture
	) as tablep
	
	

where posicao <= 3


