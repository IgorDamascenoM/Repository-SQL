USE [2RPNET]
GO

/****** Object:  Table [dbo].[Sales.SpecialOfferProduct]    Script Date: 22/12/2021 18:25:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sales.SpecialOfferProduct](
	[SpecialOfferID] [int] NOT NULL,
	[ProductID] [int] NOT NULL,
	[rowguid] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
 CONSTRAINT [pk_specialoffer] PRIMARY KEY CLUSTERED 
(
	[SpecialOfferID] ASC,
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Sales.SpecialOfferProduct]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SpecialOfferProduct]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

ALTER TABLE [dbo].[Sales.SpecialOfferProduct]  WITH CHECK ADD FOREIGN KEY([ProductID])
REFERENCES [dbo].[Production.Product] ([ProductID])
GO

