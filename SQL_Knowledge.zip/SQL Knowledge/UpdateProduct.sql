/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ProductID]
      ,[Name]
      ,[ProductNumber]
      ,[MakeFlag]
      ,[FinishedGoodsFlag]
      ,[Color]
      ,[SafetyStockLevel]
      ,[ReorderPoint]
      ,[StandardCost]
      ,[ListPrice]
      ,[Size]
      ,[SizeUnitMeasureCode]
      ,[WeightUnitMeasureCode]
      ,[Weight]
      ,[DaysToManufacture]
      ,[ProductLine]
      ,[Class]
      ,[Style]
      ,[ProductSubcategoryID]
      ,[ProductModelID]
      ,[SellStartDate]
      ,[SellEndDate]
      ,[DiscontinuedDate]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [2RPNET].[dbo].[Production.Product]

  update [2RPNET].[dbo].[Production.Product]
  
  set ProductID = null
  
  where ProductID ='NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Name = null
  where Name = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ProductNumber = null 
  where ProductNumber = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set MakeFlag = null
  where MakeFlag = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set FinishedGoodsFlag = null
  where FinishedGoodsFlag = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Color = null
  where Color = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set SafetyStockLevel = null
  where SafetyStockLevel ='NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ReorderPoint = null
  where ReorderPoint = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set StandardCost = null
  where StandardCost = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ListPrice = null
  where ListPrice = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Size = null
  where Size = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set SizeUnitMeasureCode = null
  where SizeUnitMeasureCode = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set WeightUnitMeasureCode = null
  where WeightUnitMeasureCode = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Weight = null
  where Weight = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set DaysToManufacture = null
  where DaysToManufacture = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ProductLine = null
  where ProductLine = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Class = null
  where Class = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set Style = null
  where Style = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ProductSubcategoryID = null
  where ProductSubcategoryID = 'NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set ProductModelID = null
  where ProductModelID ='NULL'
  
  update [2RPNET].[dbo].[Production.Product]
  
  set rowguid = null
  where rowguid = 'NULL'