--3.	Escreva uma query ligando as 
--tabelas Person.Person, Sales.Customer e Sales.SalesOrderHeader de forma a obter 
--uma lista de nomes de clientes e uma contagem de pedidos efetuados.

select c.BusinessEntityID, c.FirstName, c.LastName, COUNT (SalesOrderID) as compras from [Sales.SalesOrderHeader] as a

inner join [Sales.Customer] as b

on a.CustomerID = b.CustomerID

inner join [Person.Person] as c

on b.PersonID = c.BusinessEntityID

group by c.BusinessEntityID, c.FirstName, c.LastName