USE [2RPNET]
GO

/****** Object:  Table [dbo].[Person.Person]    Script Date: 22/12/2021 18:04:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Person.Person](
	[BusinessEntityID] [int] IDENTITY(1,1) NOT NULL,
	[PersonType] [varchar](50) NULL,
	[NameStyle] [varchar](50) NULL,
	[Title] [varchar](50) NULL,
	[FirstName] [varchar](50) NULL,
	[MiddleName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Suffix] [varchar](2000) NULL,
	[EmailPromotion] [varchar](50) NULL,
	[AdditionalContactInfo] [varchar](255) NULL,
	[Demographics] [varchar](255) NULL,
	[rowguid] [varchar](255) NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Person.Person] PRIMARY KEY CLUSTERED 
(
	[BusinessEntityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


