--Escreva uma query usando as tabelas Sales.SalesOrderHeader, Sales.SalesOrderDetail e Production.Product,
--de forma a obter a soma total de produtos (OrderQty) por ProductID e OrderDate.

select SUM (OrderQty) as SomaTotal, c.Name, c.ProductID, a.OrderDate from [Sales.SalesOrderHeader] as a
inner join [Sales.SalesOrderDetail] as b
on a.SalesOrderID = b.SalesOrderID
inner join [Production.Product] as c
on b.ProductID = c.ProductID

group by c.ProductID, a.OrderDate, c.Name

order by c.Name