USE [2RPNET]
GO

/****** Object:  Table [dbo].[Production.Product]    Script Date: 22/12/2021 18:23:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Production.Product](
	[ProductID] [int] NOT NULL,
	[Name] [varchar](50) NULL,
	[ProductNumber] [varchar](50) NULL,
	[MakeFlag] [varchar](50) NULL,
	[FinishedGoodsFlag] [varchar](50) NULL,
	[Color] [varchar](50) NULL,
	[SafetyStockLevel] [int] NULL,
	[ReorderPoint] [varchar](50) NULL,
	[StandardCost] [float] NULL,
	[ListPrice] [float] NULL,
	[Size] [varchar](50) NULL,
	[SizeUnitMeasureCode] [varchar](50) NULL,
	[WeightUnitMeasureCode] [varchar](50) NULL,
	[Weight] [varchar](50) NULL,
	[DaysToManufacture] [int] NULL,
	[ProductLine] [varchar](50) NULL,
	[Class] [varchar](50) NULL,
	[Style] [varchar](50) NULL,
	[ProductSubcategoryID] [varchar](50) NULL,
	[ProductModelID] [varchar](50) NULL,
	[SellStartDate] [varchar](50) NULL,
	[SellEndDate] [varchar](50) NULL,
	[DiscontinuedDate] [varchar](50) NULL,
	[rowguid] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Production.Product] PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


