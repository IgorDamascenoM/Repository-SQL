--1.	Escreva uma query que retorna a quantidade de linhas na tabela Sales.SalesOrderDetail pelo campo SalesOrderID, desde que tenham pelo menos tr�s linhas de detalhes.
select
	count (*) as qtdlinhas
from (

	select 
		count (SalesOrderDetailID) as qtd, 
		SalesOrderID
	from [Sales.SalesOrderDetail]
	group by SalesOrderID

) as a

where qtd >= 3